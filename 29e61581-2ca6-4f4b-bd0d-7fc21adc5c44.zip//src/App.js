import React, { useEffect, useState } from "react";

export default function App() {
  return (
    <>
      <h1>Todo's</h1>
      <RenderTodos />
    </>
  );
}

function RenderTodos() {
  const [todo, setTodo] = useState([]);

  useEffect(() => {
    fetch("https://sum-server.100xdevs.com/todos").then(async (res) => {
      const json = await res.json();
      const data = json.todos;

      setTodo(
        data.map((todo) => (
          <div key={todo.id}>
            <div>{todo.title}</div>
            <div>{todo.description}</div>
            <div>{todo.completed}</div>
          </div>
        ))
      );
    });
  }, []);
  return (
    <>
      <div>{todo}</div>
    </>
  );
}
